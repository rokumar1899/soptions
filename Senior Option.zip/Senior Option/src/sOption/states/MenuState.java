package sOption.states;

import java.awt.*;

import sOption.Connector;
import sOption.gfx.Assets;

public class MenuState extends State
{
	
	public MenuState(Connector c)
	{
		super(c);
	}
	
	public void tick()
	{
		if(connector.getKeyManager().getU())
		{
			State.setState(connector.getGame().gameState);
		}
	}
	
	public boolean gameOver() 
	{
		return false;
	}

	public void render(Graphics g) 
	{
		g.drawImage(Assets.title, 0, 0, 1920, 1080, null);
	}
	
}
