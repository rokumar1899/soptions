package sOption;

import sOption.display.*;

public class Launcher 
{
	public static void main(String[] args)
	{
		Game game = new Game("Soptions Project", 1920, 1080);
		game.start();
	}
}
