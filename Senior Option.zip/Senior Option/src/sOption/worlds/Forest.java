package sOption.worlds;

import java.awt.*;
import sOption.Connector;
import sOption.entities.Entity;
import sOption.entities.Tree;
import sOption.entities.unit.Goat;
import sOption.entities.unit.Rabbit;
import sOption.gfx.Assets;

public class Forest extends Region
{
	public Forest(Connector c)
	{
		super(c);
		setWidth(4500);
		setHeight(4000);
		setRegion(this);
		map = Assets.forest;
		for(int i=0; i<=3500; i+=500)
		{
			for(int j=0; j<=4000; j+=500)
			{
				int randX = (int)(Math.random()*(j+500))+j;
				int randY = (int)(Math.random()*(i+500))+i;
				if(randX == c.getEntityManager().getPlayer().getXloc() 
						&& randY == c.getEntityManager().getPlayer().getYloc())
					continue;
				c.getWorld().getEntityManager().addEntity(new Tree(c, randX, randY));
			}
		}
		
		for(int i = 0; i <= 10; i++)
		{
			Entity x = new Rabbit(c, 400*i, 350*i);
			c.getEntityManager().addEntity(x);
		}
	
			
	}
	
	public String portalMove()
	{
		if(connector.getEntityManager().getPlayer().getXloc() >= 1866
				&& connector.getEntityManager().getPlayer().getXloc() <= 2305
				&& connector.getEntityManager().getPlayer().getYloc() >= 3767)
		{
			return "beach";
		}
		else if(connector.getEntityManager().getPlayer().getXloc() >= 3488
				&& connector.getEntityManager().getPlayer().getXloc() <= 3954
				&& connector.getEntityManager().getPlayer().getYloc() <= 242)
		{
			return "mountain";
		}
		else
		{
			return "";
		}	
	}
	
	public void tick()
	{
		int xStart = (int)connector.getGameCamera().getxOffset();
		int yStart = (int)connector.getGameCamera().getyOffset();
		
		currentMap = map.crop(xStart, yStart, connector.getWidth(), connector.getHeight());
		
		if(portalMove().equals("beach"))
		{
			connector.getEntityManager().deleteTrees();
			connector.getEntityManager().deleteRabbits();
			setRegion(new Beach(connector));
			connector.getEntityManager().getPlayer().setYloc(200);
			connector.getEntityManager().getPlayer().setXloc(2554);
		}
		else if(portalMove().equals("mountain"))
		{
			connector.getEntityManager().deleteTrees();
			connector.getEntityManager().deleteRabbits();
			setRegion(new Mountain(connector));
			connector.getEntityManager().getPlayer().setYloc(2777);
			connector.getEntityManager().getPlayer().setXloc(1027);
		}
			
	
	}
	
	public void render(Graphics g)
	{
		g.drawImage(currentMap, 0, 0, connector.getWidth(), connector.getHeight(), null);
	}
}
