package sOption.worlds;

import java.awt.*;
import sOption.Connector;
import sOption.entities.unit.*;
import sOption.gfx.Assets;

public class Beach extends Region
{
	public Beach(Connector c)
	{
		super(c);
		setWidth(4000);
		setHeight(3000);
		setRegion(this);
		map = Assets.beach;
		
		}

	@Override
	public String portalMove() 
	{
		//2504, 0; 2619, 73
		if(connector.getEntityManager().getPlayer().getXloc() >= 2504
				&& connector.getEntityManager().getPlayer().getXloc() <= 2619
				&& connector.getEntityManager().getPlayer().getYloc() <= 133)
		{
			return "forest";
		}
			return "";
	}

	@Override
	public void tick() 
	{
		int xStart = (int)connector.getGameCamera().getxOffset();
		int yStart = (int)connector.getGameCamera().getyOffset();
		
		currentMap = map.crop(xStart, yStart, connector.getWidth(), connector.getHeight());
		
		if(connector.getWorld().getEntityManager().getPlayer().getYloc() >= 1600)
		{
			connector.getWorld().getEntityManager().getPlayer().setYloc(1599);
		}
		
		if(portalMove().equals("forest"))
		{
			setRegion(new Forest(connector));
			connector.getEntityManager().getPlayer().setYloc(3451);
			connector.getEntityManager().getPlayer().setXloc(1880);
		}
		
	}

	@Override
	public void render(Graphics g) 
	{
		g.drawImage(currentMap, 0, 0, connector.getWidth(), connector.getHeight(), null);
	}
	
}
