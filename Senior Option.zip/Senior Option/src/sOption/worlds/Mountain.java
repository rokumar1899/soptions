package sOption.worlds;

import java.awt.*;
import sOption.Connector;
import sOption.entities.Entity;
import sOption.entities.Tree;
import sOption.entities.unit.Goat;
import sOption.gfx.Assets;

public class Mountain extends Region
{
	public Mountain(Connector c)
	{
		super(c);
		setWidth(4000);
		setHeight(3000);
		setRegion(this);
		map = Assets.mountain;
		for(int i= 500; i<= 2500; i+=600)
		{
			for(int j=0; j<= 3500; j+=600)
			{
				int randX = (int)(Math.random()*(j+500))+j;
				int randY = (int)(Math.random()*(i+500))+i;
				if(randX == c.getEntityManager().getPlayer().getXloc() 
						&& randY == c.getEntityManager().getPlayer().getYloc())
					continue;
				c.getWorld().getEntityManager().addEntity(new Tree(c, randX, randY));
			}
		}
		
		for(int i = 0; i <= 5; i++)
		{
			Entity x = new Goat(c, 350*i, 250*i);
			c.getEntityManager().addEntity(x);
		}
	}
	
	public String portalMove()
	{
		if(connector.getEntityManager().getPlayer().getXloc() >= 916
				&& connector.getEntityManager().getPlayer().getXloc() <= 1217
				&& connector.getEntityManager().getPlayer().getYloc() >= 2818)
		{
			return "forest";
		}
		else
		{
			return "";
		}
	}
	
	public void tick()
	{
		int xStart = (int)connector.getGameCamera().getxOffset();
		int yStart = (int)connector.getGameCamera().getyOffset();
		
		currentMap = map.crop(xStart, yStart, connector.getWidth(), connector.getHeight());
	
		if(portalMove().equals("forest"))
		{
			connector.getEntityManager().deleteTrees();
			connector.getEntityManager().deleteGoats();
			setRegion(new Forest(connector));
			connector.getEntityManager().getPlayer().setYloc(500);
			connector.getEntityManager().getPlayer().setXloc(3700);
		}
	
	}
	
	public void render(Graphics g)
	{
		g.drawImage(currentMap, 0, 0, connector.getWidth(), connector.getHeight(), null);
	}
}
