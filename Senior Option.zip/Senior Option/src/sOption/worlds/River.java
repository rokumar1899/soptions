package sOption.worlds;

import java.awt.*;
import sOption.Connector;
import sOption.gfx.Assets;

public class River extends Region
{
	public River(Connector c)
	{
		super(c);
		setWidth(10000);
		setHeight(8000);
		setRegion(this);
		map = Assets.river;
	}
	
	public String portalMove()
	{
		if(connector.getEntityManager().getPlayer().getXloc() <= 421
				&& connector.getEntityManager().getPlayer().getYloc() <= 3838
				&& connector.getEntityManager().getPlayer().getYloc() >= 4254)
		{
			return "plain";
		}
		else
		{
			return "";
		}
	}
	
	public void tick()
	{
		int xStart = (int)connector.getGameCamera().getxOffset();
		int yStart = (int)connector.getGameCamera().getyOffset();
		
		currentMap = map.crop(xStart, yStart, connector.getWidth(), connector.getHeight());

		if(portalMove().equals("plain"))
		{
			setRegion(new Plain(connector));
			connector.getEntityManager().getPlayer().setYloc(4305);
			connector.getEntityManager().getPlayer().setXloc(9336);
		}
	}
	
	public void render(Graphics g)
	{
		g.drawImage(currentMap, 0, 0, connector.getWidth(), connector.getHeight(), null);
	}
}
