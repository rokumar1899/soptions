package sOption.worlds;

import java.awt.*;
import sOption.Connector;
import sOption.gfx.Assets;

public class Plain extends Region
{
	public Plain(Connector c)
	{
		super(c);
		setWidth(10000);
		setHeight(8000);
		setRegion(this);
		map = Assets.plain;
	}
	
	public String portalMove()
	{
		if(connector.getEntityManager().getPlayer().getXloc() <= 421
				&& connector.getEntityManager().getPlayer().getYloc() <= 3338
				&& connector.getEntityManager().getPlayer().getYloc() >= 3654)
		{
			return "forest";
		}
		else if(connector.getEntityManager().getPlayer().getXloc() >= 2786
				&& connector.getEntityManager().getPlayer().getXloc() <= 3131
				&& connector.getEntityManager().getPlayer().getYloc() <= 327)
		{
			return "mountain";
		}
		else if(connector.getEntityManager().getPlayer().getXloc() >= 9637
				&& connector.getEntityManager().getPlayer().getYloc() <= 3957
				&& connector.getEntityManager().getPlayer().getYloc() <= 4156)
		{
			return "river";
		}
		else
		{
			return "";
		}
	}
	
	public void tick()
	{
		int xStart = (int)connector.getGameCamera().getxOffset();
		int yStart = (int)connector.getGameCamera().getyOffset();
		
		currentMap = map.crop(xStart, yStart, connector.getWidth(), connector.getHeight());
		
		if(portalMove().equals("forest"))
		{
			setRegion(new Forest(connector));
			connector.getEntityManager().getPlayer().setYloc(2896);
			connector.getEntityManager().getPlayer().setXloc(7729);
		}
		else if(portalMove().equals("mountain"))
		{
			setRegion(new Mountain(connector));
			connector.getEntityManager().getPlayer().setYloc(4728);
			connector.getEntityManager().getPlayer().setXloc(278);
		}
		else if(portalMove().equals("river"))
		{
			setRegion(new River(connector));
			connector.getEntityManager().getPlayer().setYloc(3415);
			connector.getEntityManager().getPlayer().setXloc(514);
		}
	}
	
	public void render(Graphics g)
	{
		g.drawImage(currentMap, 0, 0, connector.getWidth(), connector.getHeight(), null);
	}
}
