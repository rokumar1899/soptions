package sOption.gfx;

import java.awt.image.BufferedImage;

public class Assets 
{
	public static BufferedImage[] player_down, player_up, player_left, player_right, treeA;
	public static BufferedImage[] goat_down, goat_up, goat_left, goat_right;
	public static BufferedImage[] rabbit_down, rabbit_up, rabbit_left, rabbit_right;
	public static SpriteSheet beach, river, plain, forest, mountain, village, tree, goat, rabbit;
	public static BufferedImage title;
	
	public static void init()
	{
		SpriteSheet player = new SpriteSheet(ImageLoader.loadImage("/Unit/Player.png"));
	
		player_down = new BufferedImage[4];
		player_down[0] = player.crop(0, 512, 256, 512);
		player_down[1] = player.crop(256, 512, 256, 512);
		player_down[2] = player.crop(512, 512, 256, 512);
		player_down[3] = player.crop(768, 512, 256, 512);
		
		player_up = new BufferedImage[4];
		player_up[0] = player.crop(0, 0, 256, 512);
		player_up[1] = player.crop(256, 0, 256, 512);
		player_up[2] = player.crop(512, 0, 256, 512);
		player_up[3] = player.crop(768, 0, 256, 512);
		
		player_right = new BufferedImage[4];
		player_right[0] = player.crop(0, 1024, 256, 512);
		player_right[1] = player.crop(256, 1024, 256, 512);
		player_right[2] = player.crop(512, 1024, 256, 512);
		player_right[3] = player.crop(768, 1024, 256, 512);
		
		player_left = new BufferedImage[4];
		player_left[0] = player.crop(0, 1536, 256, 512);
		player_left[1] = player.crop(256, 1536, 256, 512);
		player_left[2] = player.crop(512, 1536, 256, 512);
		player_left[3] = player.crop(768, 1536, 256, 512);
		
		beach = new SpriteSheet(ImageLoader.loadImage("/Regions/Beach.png"));
		forest = new SpriteSheet(ImageLoader.loadImage("/Regions/Forest.png"));
		plain = new SpriteSheet(ImageLoader.loadImage("/Regions/Plain.png"));
		mountain = new SpriteSheet(ImageLoader.loadImage("/Regions/Mountain.png"));
		river = new SpriteSheet(ImageLoader.loadImage("/Regions/River.png"));
		village = new SpriteSheet(ImageLoader.loadImage("/Regions/Village.png"));
		tree = new SpriteSheet(ImageLoader.loadImage("/Structure/Tree.png"));
		
		treeA = new BufferedImage[1];
		treeA[0] = tree.crop(0, 0, 65, 98);
		
		goat = new SpriteSheet(ImageLoader.loadImage("/Unit/Goat.png"));
	
		goat_down = new BufferedImage[4];
		goat_down[0] = goat.crop(0, 256, 128, 128);
		goat_down[1] = goat.crop(128, 256, 128, 128);
		goat_down[2] = goat.crop(256, 256, 128, 128);
		goat_down[3] = goat.crop(384, 256, 128, 128);
		
		goat_up = new BufferedImage[4];
		goat_up[0] = goat.crop(0, 0, 128, 128);
		goat_up[1] = goat.crop(128, 0, 128, 128);
		goat_up[2] = goat.crop(256, 0, 128, 128);
		goat_up[3] = goat.crop(384, 0, 128, 128);
		
		goat_left = new BufferedImage[4];
		goat_left[0] = goat.crop(0, 128, 128, 128);
		goat_left[1] = goat.crop(128, 128, 128, 128);
		goat_left[2] = goat.crop(256, 128, 128, 128);
		goat_left[3] = goat.crop(384, 128, 128, 128);
		
		goat_right = new BufferedImage[4];
		goat_right[0] = goat.crop(0, 384, 128, 128);
		goat_right[1] = goat.crop(128, 384, 128, 128);
		goat_right[2] = goat.crop(256, 384, 128, 128);
		goat_right[3] = goat.crop(384, 384, 128, 128);
		
		rabbit = new SpriteSheet(ImageLoader.loadImage("/Unit/Rabbit.png"));
		
		rabbit_down = new BufferedImage[2];
		rabbit_down[0] = rabbit.crop(0, 300, 100, 100);
		rabbit_down[1] = rabbit.crop(100, 300, 100, 100);
		
		rabbit_up = new BufferedImage[2];
		rabbit_up[0] = rabbit.crop(0, 200, 100, 100);
		rabbit_up[1] = rabbit.crop(100, 200, 100, 100);
		
		rabbit_left = new BufferedImage[2];
		rabbit_left[0] = rabbit.crop(0, 0, 100, 100);
		rabbit_left[1] = rabbit.crop(100, 0, 100, 100);
		
		rabbit_right = new BufferedImage[2];
		rabbit_right[0] = rabbit.crop(0, 100, 100, 100);
		rabbit_right[1] = rabbit.crop(100, 100, 100, 100);
		
		title = new SpriteSheet(ImageLoader.loadImage("/Title.png")).crop(0, 0, 1920, 1080);
	}
}
