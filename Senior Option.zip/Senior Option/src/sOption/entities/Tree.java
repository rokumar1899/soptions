package sOption.entities;

import java.awt.Graphics;
import java.awt.Rectangle;
import java.awt.event.KeyEvent;

import sOption.Connector;
import sOption.gfx.*;
import sOption.items.*;
import sOption.items.resources.*;
import java.util.ArrayList;

public class Tree extends Structure 
{
	public Animation treeA;
	
	public Tree(Connector c, float x, float y) 
	{
		super(c, x, y, 75, 150, 20, "Tree");
		treeA = new Animation(1000, Assets.treeA);
	}
	
	public void generateDrops() 
	{
		this.getDrops().add(new Wood(connector));
		this.getDrops().add(new Wood(connector));
		this.getDrops().add(new Leaf(connector));
	}
	
	public void interact()
	{
		if(this.getBoundary().intersects(connector.getWorld().getEntityManager().getPlayer().getBoundary()) && this.getHealth()==0);
		{
			for(Item x: this.getDrops())
				connector.getWorld().getEntityManager().getPlayer().getDrops().add(x);
		}
	}
	
	public Rectangle getCollisionBounds(float xOffset, float yOffset)
	{
		return new Rectangle((int)(xloc + 20 + xOffset), (int)(yloc + 100 + yOffset), boundary.width - 20, boundary.height - 100);
	}	
	
	public void tick()
	{
		if(getHealth() <= 0)
		{
			setAlive(false);
		}
	}
	
	
	public void render(Graphics g)
	{
		g.drawImage(Assets.treeA[0], (int) (getXloc() - connector.getGameCamera().getxOffset()), (int) (getYloc() - connector.getGameCamera().getyOffset()), getWidth(), getHeight(), null);
	}

}