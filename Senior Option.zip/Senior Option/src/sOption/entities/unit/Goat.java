package sOption.entities.unit;

import sOption.Connector;
import sOption.entities.*;
import sOption.gfx.Animation;
import sOption.gfx.Assets;

import java.awt.*;
import java.awt.image.BufferedImage;


public class Goat extends Unit
{
	private Animation animDown, animUp, animRight, animLeft;
	
	private int count;
	
	public Goat(Connector c, float x, float y)
	{
		super(c, x, y, 200, 200, 70, 2, 5);
		setName("Goat");
		this.alive = true;
		animDown = new Animation(250, Assets.goat_down);
		animUp = new Animation(250, Assets.goat_up);
		animLeft = new Animation(250, Assets.goat_left);
		animRight = new Animation(250, Assets.goat_right);
		
		while(this.checkEntityCollisions(0f, 0f))
		{
			xloc += 25;
			yloc += 25;
		}
	}
	
	@Override
	public void tick()
	{
		animDown.tick();
		animUp.tick();
		animLeft.tick();
		animRight.tick();
		
		count++;
		if(count >= 180)
		{
			count = 0;
			xMove = (float)Math.random()*2*speed- speed;
			yMove = (float)Math.random()*2*speed - speed;
		}
		move();
	}
	
	public Rectangle getCollisionBounds(float xOffset, float yOffset)
	{
		return new Rectangle((int)(xloc + 50 + xOffset), (int)(yloc + 50 + yOffset), boundary.width - 100, boundary.height - 50);
	}
	
	@Override
	public void render(Graphics g)
	{
		g.drawImage(getCurrentAnimationFrame(), (int) (getXloc() - connector.getGameCamera().getxOffset()), (int) (getYloc() - connector.getGameCamera().getyOffset()), getWidth(), getHeight(), null);
	}
	
	private BufferedImage getCurrentAnimationFrame()
	{
		if(xMove < 0) //moving left
		{
			return animLeft.getCurrentFrame();
		}
		else if(xMove > 0) //moving right
		{
			return animRight.getCurrentFrame();
		}
		else if(yMove < 0) //moving up
		{
			return animUp.getCurrentFrame();
		}
		else
		{
			return animDown.getCurrentFrame();
		}
	}
}